
package driver;

public class OPUSCard {
    //privat variable (datafield)
    private String cardType;
    private String nameOfHolder;
    private int expiryMonth;
    private int expiryYear;

    // Default constructor
    public OPUSCard() {
    }

    // Parameterized constructor
    public OPUSCard(String cardType, String nameOfHolder, int expiryMonth, int expiryYear) {
        this.cardType = cardType;
        this.nameOfHolder = nameOfHolder;
        this.expiryMonth = expiryMonth;
        this.expiryYear = expiryYear;
    }

    // Copy constructor
    public OPUSCard(OPUSCard card) {
        this.cardType = card.cardType;
        this.nameOfHolder = card.nameOfHolder;
        this.expiryMonth = card.expiryMonth;
        this.expiryYear = card.expiryYear;
    }

    // accessor method for cardType
    public String getCardType() {
        return cardType;
    }

    // accesor method for nameOfHolder
    public String getNameOfHolder() {
        return nameOfHolder;
    }

    // accessor method for expiryMonth
    public int getExpiryMonth() {
        return expiryMonth;
    }

    // mutator method for expiryMonth
    public void setExpiryMonth(int expiryMonth) {
        if (expiryMonth >= 1 && expiryMonth <= 12)
            this.expiryMonth = expiryMonth;

        else
            this.expiryMonth = 0;
    }

    // accessor method for expiryYear
    public int getExpiryYear() {
        return expiryYear;
    }

    // mutator method for expiryYear
    public void setExpiryYear(int expiryYear) {
        this.expiryYear = expiryYear;
    }

    // toString() method
    @Override
    public String toString() {
        String expiryDate;
        if (expiryMonth < 10)
            expiryDate = "0" + expiryMonth + "/" + expiryYear;

        else
            expiryDate = expiryMonth + "/" + expiryYear;

        return cardType + "-" + nameOfHolder + "-" + expiryDate;
    }

    // method to check if two OPUSCard objects are equal
    public boolean equals(OPUSCard card) {
        return this == card;
    }
}
