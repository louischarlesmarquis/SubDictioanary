
package driver;

public class Tickets {
    // static contants for values of tickets
    private static final double REGULAR_TICKET = 3.50;
    private static final double JUNIOR_TICKET = 2.50;
    private static final double SENIOR_TICKET = 1;
    private static final double DAILY_TICKET = 10;
    private static final double WEEKLY_TICKET = 40;

    // variables for number of tickets
    private int noRegularTicket;
    private int noJuniorTicket;
    private int noSeniorTicket;
    private int noDailyTicket;
    private int noWeeklyTicket;

    // Default constructor
    public Tickets() {
    }

    // Parameterized constructor
    public Tickets(int noRegularTicket, int noJuniorTicket, int noSeniorTicket, int noDailyTicket, int noWeeklyTicket) {
        this.noRegularTicket = noRegularTicket;
        this.noJuniorTicket = noJuniorTicket;
        this.noSeniorTicket = noSeniorTicket;
        this.noDailyTicket = noDailyTicket;
        this.noWeeklyTicket = noWeeklyTicket;
    }

    // Copy constructor
    public Tickets(Tickets tickets) {
        this.noRegularTicket = tickets.noRegularTicket;
        this.noJuniorTicket = tickets.noJuniorTicket;
        this.noSeniorTicket = tickets.noSeniorTicket;
        this.noDailyTicket = tickets.noDailyTicket;
        this.noWeeklyTicket = tickets.noWeeklyTicket;
    }

    // accessor method for noRegularTicket
    public int getNoRegularTicket() {
        return noRegularTicket;
    }

    // mutator method for noRegularTicket
    public void setNoRegularTicket(int noRegularTicket) {
        this.noRegularTicket = noRegularTicket;
    }

    // accessor method for noJuniorTicket
    public int getNoJuniorTicket() {
        return noJuniorTicket;
    }

    // mutator method for noJuniorTicket
    public void setNoJuniorTicket(int noJuniorTicket) {
        this.noJuniorTicket = noJuniorTicket;
    }

    // accessor method for noSeniorTicket
    public int getNoSeniorTicket() {
        return noSeniorTicket;
    }

    // mutator method for noSeniorTicket
    public void setNoSeniorTicket(int noSeniorTicket) {
        this.noSeniorTicket = noSeniorTicket;
    }

    // accessor method for noDailyTicket
    public int getNoDailyTicket() {
        return noDailyTicket;
    }

    // mutator method for noDailyTicket
    public void setNoDailyTicket(int noDailyTicket) {
        this.noDailyTicket = noDailyTicket;
    }

    // accessor method for noWeeklyTicket
    public int getNoWeeklyTicket() {
        return noWeeklyTicket;
    }

    // mutator method for noWeeklyTicket
    public void setNoWeeklyTicket(int noWeeklyTicket) {
        this.noWeeklyTicket = noWeeklyTicket;
    }

    // method to increase number of tickets
    public void addTickets(int regularTicket, int juniorTicket, int seniorTicket, int dailyTicket, int weeklyTicket) {
        this.noRegularTicket += regularTicket;
        this.noJuniorTicket += juniorTicket;
        this.noSeniorTicket += seniorTicket;
        this.noDailyTicket += dailyTicket;
        this.noWeeklyTicket += weeklyTicket;
    }

    // method to get total value of tickets
    public double ticketsTotal() {
        return noRegularTicket*3.5 + noJuniorTicket*2.5 + noSeniorTicket + noDailyTicket*10 + noWeeklyTicket*40;
    }

    // toString() method
    @Override
    public String toString() {
        return noRegularTicket + "x $3.50 + " + noJuniorTicket + " x $2.50 + " 
             + noSeniorTicket + " x $1.00 + " + noDailyTicket + " x $10.00 + " 
             + noWeeklyTicket + " x $40.00 + ";
    }

    // method to check if two Ticket objects are equal
    public boolean equals(Tickets tickets) {
        return this == tickets;
    }

}