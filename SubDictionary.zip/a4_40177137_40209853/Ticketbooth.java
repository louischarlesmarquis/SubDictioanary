
package driver;

public class Ticketbooth {
    private Tickets tickets;
    private OPUSCard[] opusCards;

    // Default constructor
    public Ticketbooth() {
        tickets = new Tickets();
        opusCards = new OPUSCard[50];
    }

    // Parameterized constructor
    public Ticketbooth(Tickets tickets, OPUSCard[] opusCard) {
        this.tickets = tickets;
        this.opusCards = opusCard;
    }

    // method to compare ticket value of two Ticketbooth objects
    public boolean equalTicketValue(Ticketbooth ticketbooth) {
        return this.tickets.ticketsTotal() == ticketbooth.tickets.ticketsTotal();
    }

    // method to compare number of each type of tickets
    public boolean equalNoOfTickets(Ticketbooth ticketbooth) {
        return this.tickets.getNoRegularTicket() == ticketbooth.tickets.getNoRegularTicket() && this.tickets.getNoJuniorTicket() == ticketbooth.tickets.getNoJuniorTicket() && this.tickets.getNoSeniorTicket() == ticketbooth.tickets.getNoSeniorTicket() && this.tickets.getNoDailyTicket() == ticketbooth.tickets.getNoDailyTicket() && this.tickets.getNoWeeklyTicket() == ticketbooth.tickets.getNoWeeklyTicket();
    }

    // method to return total value of tickets
    public double totalValueOfTickets() {
        return this.tickets.ticketsTotal();
    }

    // method to return number of OPUS cards
    public int noOfOPUSCards() {
        return opusCards.length;
    }

    // method to add a new OPUS card
    public int addOPUSCard(OPUSCard card) {
        for (int i = 0; i < opusCards.length; i++) {
            if (opusCards[i] == null) {
                opusCards[i] = card;
                return (i + 1);
            }  
        }
        // if the array is full
        OPUSCard[] newOPUSCards = new OPUSCard[opusCards.length + 50];
        int i;
        for (i = 0; i < opusCards.length; i++) {
            newOPUSCards[i] = opusCards[i];
        }
        newOPUSCards[i] = card;
        opusCards = newOPUSCards;
        return (i + 1);
    }

    public boolean removeOPUSCard2() {
        // if there are no OPUS cards
        if (null == opusCards[0])
            return true;
        else
            return false;
    }
    
    // method to remove an OPUS card based on cardHolder
    public boolean removeOPUSCard(String cardHolder) {
        // if there are no OPUS cards
        if (opusCards[0] == null)
            return false;

        OPUSCard[] newOPUSCards = new OPUSCard[opusCards.length];
        for (int i = 0; i < opusCards.length; i++) {
            if (opusCards[i].getNameOfHolder() == cardHolder)
                continue;

            newOPUSCards[i] = opusCards[i];
        }
        opusCards = newOPUSCards;
        return true;
    }

    // method to update expiry month and expiry year of an OPUS card
    public void updateExpiryDate(String cardHolder, int expiryMonth, int expiryYear) {
        for (OPUSCard opusCard : opusCards) {
            if (opusCard.getNameOfHolder().equals(cardHolder)) {
                opusCard.setExpiryMonth(expiryMonth);
                opusCard.setExpiryYear(expiryYear);
            }
        }
    }

    // method to add tickets to the ticketbooth
    public int addTicketsToBooth(int regularTicket, int juniorTicket, int seniorTicket, int dailyTicket, int weeklyTicket) {
        this.tickets.addTickets(regularTicket, juniorTicket, seniorTicket, dailyTicket, weeklyTicket);
        
        return (this.tickets.getNoRegularTicket() + this.tickets.getNoJuniorTicket() + this.tickets.getNoSeniorTicket() + this.tickets.getNoDailyTicket() + this.tickets.getNoWeeklyTicket());
    }

    // method to compare two ticketbooths
    public boolean equals(Ticketbooth ticketbooth) {
        if ((this.tickets.getNoRegularTicket() + this.tickets.getNoJuniorTicket() + this.tickets.getNoSeniorTicket() + this.tickets.getNoDailyTicket() + this.tickets.getNoWeeklyTicket() == ticketbooth.tickets.getNoRegularTicket() + ticketbooth.tickets.getNoJuniorTicket() + ticketbooth.tickets.getNoSeniorTicket() + ticketbooth.tickets.getNoDailyTicket() + ticketbooth.tickets.getNoWeeklyTicket()) && this.opusCards.length == ticketbooth.opusCards.length)
            return true;

        return false;
    }

    // toString() method
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Ticketbooth"+"\n").append(this.tickets.toString()).append("\n");
        // if there are no OPUS cards
        if (opusCards.length == 0) {
            sb.append("No OPUS cards");
            return sb.toString();
        } else if (opusCards[0] == null){
            sb.append("No OPUS cards");
            return sb.toString();
        } else {
            // else
            for (OPUSCard opusCard : opusCards) {
                sb.append(opusCard.toString()).append("\n");
            }
            return sb.toString();
        }
    }

    // method to return string showing breakdown of tickets
    public String returnTickets() {
        return this.tickets.toString();
    }
}