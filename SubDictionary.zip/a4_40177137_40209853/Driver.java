package driver;
//import scanner class
import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        
        // -------------------------------------------------------
        // Assignment 4
        // Written by: Louis-Charles Marquis - 40177137 & Vlad Tita - 40209853
        // For COMP 248 Section C & B – Fall 2021
        // Date: December 6th, 2021
        // --------------------------------------------------------
        
        /*
        This program simulates a ticketbooth which holds tickets and OPUS cards by the use of 
        a Tickets class, a OPUSCard class, a Ticketbooth class and a driver class  
        */
        
        //Welcome message
        System.out.println("=============================================================================");
        System.out.println("       Welcome to Concordia 2021 Fall Geek's Ticketbooth Application");
        System.out.println("=============================================================================");
        
        //create instances of object tickets
        Tickets tickets1 = new Tickets(5,1,0,1,1);
        OPUSCard[] opusCards1 = {new OPUSCard("STM", "M.Cola", 8, 2024), new OPUSCard("RTL", "C.Venus", 3, 2025)};
        OPUSCard[] opusCards1x = {new OPUSCard("STM", "M.Cola", 8, 2024), new OPUSCard("STM", "Z.Poker", 10, 2022)};
        
        //create a ticketbooth array
        Ticketbooth[] ticketbooths = new Ticketbooth[5];
        
        //store in a ticketbooth array
        ticketbooths[0] = new Ticketbooth(tickets1, opusCards1);
        ticketbooths[1] = new Ticketbooth(tickets1, opusCards1x);
        
        //create instances of object tickets
        Tickets tickets2 = new Tickets(5,5,5,5,5);
        OPUSCard[] opusCards2 = {new OPUSCard("RTL", "F.Max", 12, 2021), new OPUSCard("REM", "T.Fiona", 4, 2023), new OPUSCard("TRAMREM", "S.EaFL", 11, 2021)};
        
        ticketbooths[2] = new Ticketbooth(tickets2, opusCards2);

        Tickets tickets3 = new Tickets(0,1,1,1,1);
        OPUSCard[] opusCards3 = {};
        
        //store in a ticketbooth array
        ticketbooths[3] = new Ticketbooth(tickets3, opusCards3);
        ticketbooths[4] = new Ticketbooth(tickets3, opusCards3);
        
        //variable that becomes false once the user wants to quit the program
        boolean quit = true;
        
        //while loop displaying the user's choices until he decides to quit the program
        while(quit) {
            //all the user's choices
            System.out.println("\nWhat would you like to do?");
            System.out.println("1. See the content of all ticketbooths");
            System.out.println("2. See the content of one ticketbooth");
            System.out.println("3. List tickbooths with same amount of ticket's values");
            System.out.println("4. List Ticketbooths with same Tickets amount");
            System.out.println("5. List Ticketbooths with same amount of tickets values and same number of OPUS cards");
            System.out.println("6. Add a OPUS card to an existing Ticketbooth");
            System.out.println("7. Remove an existing OPUS card from a Ticketbooth");
            System.out.println("8. Update the expiry date of an existing OPUS card");
            System.out.println("9. Add Tickets to a Ticketbooth");
            System.out.println("0. To Quit");
            System.out.print("Please enter your choice and press <Enter>: ");
            //creating a scanner for user's input
            Scanner sc = new Scanner(System.in);
            int input = sc.nextInt();
            
            //using a switch statement, the program does something depending on the user's input
            switch(input) {
                case 1: {
                    System.out.println("Content of each Ticketbooth:");
                    System.out.println("----------------------------");
                    //displays the content of each ticketbooth
                    for (Ticketbooth ticketbooth : ticketbooths){
                        System.out.println(ticketbooth.toString());
                    }
                    break;
                }

                case 2: {
                    Scanner scanner = new Scanner(System.in);
                    //asks which ticketbooth the user wants to see the content of
                    System.out.print("Which Ticketbooth do you want to see the content of? (Enter number 0 to 4): ");  
                    int n = scanner.nextInt();
                    while(true){
                        //if user enters invalid input
                        if(n<0 || n>4){
                            System.out.println("Sorry but there is no Ticketbooth number " + n);
                            //asks to try again until the user gets it right
                            System.out.print("--> Try again: (Enter a number 0 to 4):");
                            n = scanner.nextInt();
                        }
                        //otherwise, print the content of the ticketbooth
                        else{
                            System.out.println(ticketbooths[n].toString());
                            //break from the loop
                            break;
                        }
                    }
                    break;
                }

                case 3: {
                    System.out.println("List of Ticketbooths with same amount of money:");
                    System.out.println();
                    //nested for loop that prints the ticketbooths with the same amount of money
                    for (int i = 0; i < ticketbooths.length; i++) {
                        for (int j = i+1; j < ticketbooths.length; j++) {
                            if (ticketbooths[i].equalTicketValue(ticketbooths[j])) {
                                System.out.println("Tickbooths "+ i + " and " + j + " both have " + ticketbooths[i].totalValueOfTickets());
                            }
                        }
                    }
                    break;
                }

                case 4: {
                    System.out.println("List of Ticketbooths with same Tickets amount:");
                    System.out.println();
                    //nested for loop that prints the ticketbooths with the same amount of tickets
                    for (int i = 0; i < ticketbooths.length; i++) {
                        for (int j = i+1; j < ticketbooths.length; j++) {
                            if (ticketbooths[i].equalNoOfTickets(ticketbooths[j])) {
                                //override toString???
                                System.out.println("\tTicketbooths " + i + " and " + j + " both have " + ticketbooths[i].toString());
                            }

                        }
                    }
                    break;
                }

                case 5: {
                    System.out.println("List of Ticketbooths with same amount of ticket values and same number of OPUS cards: ");
                    System.out.println();
                    //nested for loops that prints the ticketbooths with the same amount of ticket values and same number of OPUS cards
                    for (int i = 0; i < ticketbooths.length; i++) {
                        for (int j = i+1; j < ticketbooths.length; j++) {
                            if ((ticketbooths[i].equalTicketValue(ticketbooths[j])) && (ticketbooths[i].noOfOPUSCards() == ticketbooths[j].noOfOPUSCards())) {
                                System.out.println("\tTicketbooths " + i + " and " + j);
                            }

                        }
                    }
                    break;
                }

                case 6: {
                    //initialise a scanner for user input
                    Scanner scanner = new Scanner(System.in);
                    System.out.print("Which ticketbooth do you want to add a OPUS card to? (Enter number 0 to 4): ");
                    int n = scanner.nextInt();
                    while(true){
                        if(n<0 || n>4){
                            System.out.println("Sorry but there is no Ticketbooth number " + n);
                            System.out.print("--> Try again: (Enter a number 0 to 4):");
                            n = scanner.nextInt();
                        }
                        else{
                            break;
                        }
                    }
                    System.out.println("Please enter the following information so that we may complete the transaction-");
                    System.out.print("--> Type of OPUS card (STL, RTL, etc.): ");  
                    String cardType = scanner.next();
                    System.out.print("--> Full name on OPUS card: "); 
                    String cardHolder = scanner.next();
                    //cut the string to get the 2 int values, store in variables
                    System.out.print("-->Expiry month number and year (seperate by a space): ");  
                    int[] numbers = new int[2];
                    int i;
                    //asks the user for 2 inputs
                    for (i = 0; i < numbers.length; i++) {
                        numbers[i] = sc.nextInt();
                    }
                    int month = numbers[0];
                    int year = numbers[1];
                    System.out.println("You now have " + ticketbooths[n].addOPUSCard(new OPUSCard(cardType, cardHolder, month, year)) + " OPUS card(s)");
                    break;
                }

                case 7: {
                    Scanner scanner = new Scanner(System.in);
                    System.out.print("Which ticketbooth do you want to remove a OPUS card from? (Enter number 0 to 4): ");
                    int n = scanner.nextInt();
                    System.out.print("Enter the name of the card holder of the OPUS card you want to remove: ");
                    String name = scanner.next();
                    //if there is no opus card
                    if(ticketbooths[n].removeOPUSCard2()){
                        System.out.println("sorry this ticketbooth has no opus card");
                    }
                    //removes the opus card with the name of its holder
                    ticketbooths[n].removeOPUSCard(name);
                    System.out.println("Card was removed successfully");
                    break;
                }

                case 8: {
                    Scanner scanner = new Scanner(System.in);
                    System.out.print("Which Ticketbooth do you want to update a OPUS card from? (Enter a number 0 to 4): ");
                    int n = scanner.nextInt();
                    //if there is no card in ticketbooth n
                    if(ticketbooths[n].removeOPUSCard(null)){
                        System.out.println("Sorry but there is no card in ticketbooth number "+n);
                        //asks the user to try again
                        System.out.println("--> Try again:");
                        System.out.println("(Enter ticketbooth number 0 to 4)");
                        n = scanner.nextInt();
                    }
                    System.out.print("Enter the name of the card holder: ");
                    String name = scanner.next();
                    //cut the string to get the 2 int values, store in variables
                    System.out.print("-->Expiry month number and year (seperate by a space): "); 
                    int[] numbers = new int[2];
                    int i;
                    for (i = 0; i < numbers.length; i++) {
                        numbers[i] = sc.nextInt();
                    }
                    int month = numbers[0];
                    int year = numbers[1];
                    //updates the expiry date
                    ticketbooths[n].updateExpiryDate(name, month, year);
                    System.out.println("Entry date updated.");
                    break;
                }
                
                case 9: {
                    Scanner scanner = new Scanner(System.in);
                    //asks the user which ticketbooths he wants to add tickets to
                    System.out.print("Which Ticketbooth do you want to add tickets to? (Enter number 0 to 4): ");
                    int n = scanner.nextInt();
                    int[] types = new int[5];
                    int j;
                    System.out.print("How many regular, junior, senior, daily and weekly do you want to add?" + "\n" + "Enter 5 numbers seperated by a space): ");
                    for (j = 0; j < types.length; j++) {
                        types[j] = scanner.nextInt();
                    }
                    int regularTicket = types[0];
                    int juniorTicket = types[1];
                    int seniorTicket = types[2];
                    int dailyTicket = types[3];
                    int weeklyTicket = types[4];
                    //adds the tickets to the n ticketbooth
                    ticketbooths[n].addTicketsToBooth(regularTicket, juniorTicket, seniorTicket, dailyTicket, weeklyTicket);
                    //displaying total value of tickets in ticketbooth n
                    System.out.println("You now have $" + ticketbooths[n].totalValueOfTickets());
                    break;
                }

                case 0:
                    quit = false;
                    break;

                default:
                    System.out.println("Sorry that is not a valid choice. Try again.");
            };
        }
        //closing message
        System.out.println("Thank you for using Concordia Fall Geek's Ticketbooth application");
    }
}